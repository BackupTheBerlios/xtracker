/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.4 2005/10/18 13:59:21 spocke Exp $ 
 */  

tinyMCE.addToLang('',{
insert_advhr_desc : 'Vložit/editovat vodorovný oddělovač',
insert_advhr_width : 'Šířka',
insert_advhr_size : 'Výška',
insert_advhr_noshade : 'Nestínovat'
});

