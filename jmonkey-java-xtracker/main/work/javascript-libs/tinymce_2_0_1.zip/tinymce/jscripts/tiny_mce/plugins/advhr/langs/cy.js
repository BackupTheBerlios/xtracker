// Welsh lang variables

tinyMCE.addToLang('',{
insert_advhr_desc : 'Mewnosod/golygu llinell llorweddol',
insert_advhr_width : 'Lled',
insert_advhr_size : 'Uchder',
insert_advhr_noshade : 'Dim cysgod'
});
