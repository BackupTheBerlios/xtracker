// CA_FR lang variables

tinyMCE.addToLang('',{
insert_advhr_desc : 'Ins�rer / Modifier S�parateur Horizontal',
insert_advhr_width : 'Largeur',
insert_advhr_size : 'Hauteur',
insert_advhr_noshade : 'Sans ombrage'
});
