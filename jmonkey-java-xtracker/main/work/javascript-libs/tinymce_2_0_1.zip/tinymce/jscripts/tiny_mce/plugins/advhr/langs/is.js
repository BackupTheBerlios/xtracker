// Iceland lang variables by Johannes Birgir Jensson

tinyMCE.addToLang('',{
insert_advhr_desc : 'B&aelig;ta vi&eth;/breyta stiku',
insert_advhr_width : 'Breidd',
insert_advhr_size : 'H&aelig;&eth;',
insert_advhr_noshade : 'Enginn skuggi'
});
