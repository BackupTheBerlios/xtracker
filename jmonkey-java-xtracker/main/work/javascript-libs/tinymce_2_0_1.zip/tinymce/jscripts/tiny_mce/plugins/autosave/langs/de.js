// DE lang variables

tinyMCE.addToLang('',{
autosave_unload_msg : 'Alle Ver&auml;nderungen an dieser Seite werden verlorengehen, wenn Sie diese Seite jetzt verlassen.'
});
