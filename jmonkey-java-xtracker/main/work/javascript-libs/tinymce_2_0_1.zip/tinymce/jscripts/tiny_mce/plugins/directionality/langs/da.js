// DK lang variables contributed by Jan Moelgaard

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Retning - venstre mod h&#248;jre',
directionality_rtl_desc : 'Retning - h&#248;jre mod venstre'
});
