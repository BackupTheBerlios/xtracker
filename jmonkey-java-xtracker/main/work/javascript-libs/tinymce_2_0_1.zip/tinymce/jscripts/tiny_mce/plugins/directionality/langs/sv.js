// SV lang variables

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Riktning fr&aring;n v&auml;nster till h&ouml;ger',
directionality_rtl_desc : 'Riktning fr&aring;n h&ouml;ger till v&auml;nster'
});
