// IR lang variables
// Persian (Farsi) language pack (for IRAN)
// By: Morteza Zafari
// Lost@LostLord.com
// http://www.LostLord.com

tinyMCE.addToLang('',{
dir : 'rtl',
insert_flash : '?????? ? ?????? ???? ???',
insert_flash_file : '???? ??? (.swf)',
insert_flash_size : '?????',
flash_props : 'Flash properties'
});
