// SE lang variables

tinyMCE.addToLang('flash',{
title : 'Skapa/uppdatera flash-film',
desc : 'Skapa/uppdatera flash-film',
file : 'Flash-film (.swf)',
size : 'Storlek',
list : 'Flash-filer',
props : 'Flash egenskaper',
general : 'Generella inst&auml;llningar'
});
