// Traditional Chinese UTF-8; Twapweb Site translated; twapweb_AT_gmail_DOT_com
// 繁體中文 UTF-8 ；數位應用坊製作； twapweb_AT_gmail_DOT_com

tinyMCE.addToLang('flash',{
title : '插入或編輯 Flash 動畫檔',
desc : '插入或編輯 Flash 動畫檔',
file : 'Flash 動畫檔（ .swf ）',
size : '大小',
list : 'Flash 動畫檔',
props : 'Flash 動畫檔屬性',
general : '一般'
});
