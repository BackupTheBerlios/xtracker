// French lang variables by Laurent Dran
// Modifi� par Normand Lamoureux le 2005-11-12

tinyMCE.addToLang('',{
iespell_desc : 'Lancer le v�rificateur d\'orthographe',
iespell_download : "Le dictionnaire ieSpell n\'a pas �t� trouv�.\n\nCliquez sur Ok pour aller au site de t�l�chargement."
});
