/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.4 2005/10/18 13:59:43 spocke Exp $ 
 */  

tinyMCE.addToLang('',{
paste_text_desc : 'Vložit neformátovaný text',
paste_text_title : 'Použij CTRL + V na klávesnici pro vložení textu do okna.',
paste_text_linebreaks : 'Nechej přerušení řádků',
paste_word_desc : 'Vložit text z aplikace Word',
paste_word_title : 'Použij CTRL + V na klávesnici pro vložení textu do okna.',
selectall_desc : 'Označit vše'
});

