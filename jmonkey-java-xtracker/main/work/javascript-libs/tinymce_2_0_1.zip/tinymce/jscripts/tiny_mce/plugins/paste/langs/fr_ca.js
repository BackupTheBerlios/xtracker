// Canadian French lang variables by Virtuelcom   last modification: 2005-06-15

tinyMCE.addToLang('',{
paste_text_desc : 'Coller texte seulement',
paste_text_title : 'Utilisez CTRL+V sur votre clavier pour coller le texte dans la fen�tre.',
paste_text_linebreaks : 'Garder les sauts de ligne',
paste_word_desc : 'Coller � partir de Word',
paste_word_title : 'Utilisez CTRL+V sur votre clavier pour coller le texte dans la fen�tre.',
selectall_desc : 'Selectionner tout'
});
