/**
 * pt_br lang variables
 * Brazilian Portuguese
 *
 * Authors :
 *           Marcio Barbosa (mpg) <mpg@mpg.com.br>
 * Last Updated : November 26, 2005
 * TinyMCE Version : 2.0RC4
 */
tinyMCE.addToLang('',{
paste_text_desc : 'Colar um texto simples',
paste_text_title : 'Use CTRL+V no seu teclado para colar o texto dentro da janela.',
paste_text_linebreaks : 'Manter quebras de linha',
paste_word_desc : 'Colar do Word',
paste_word_title : 'Use CTRL+V no seu teclado para colar o texto dentro da janela.',
selectall_desc : 'Selecionar tudo'
});
