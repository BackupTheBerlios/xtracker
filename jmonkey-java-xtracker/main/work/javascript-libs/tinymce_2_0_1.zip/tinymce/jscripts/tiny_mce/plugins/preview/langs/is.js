// Iceland lang variables by Johannes Birgir Jensson

tinyMCE.addToLang('',{
preview_desc : 'Forsko&eth;a'
});
