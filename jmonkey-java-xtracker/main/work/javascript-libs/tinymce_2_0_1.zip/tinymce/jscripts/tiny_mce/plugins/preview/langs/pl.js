// PL lang variables
// fixed by Wooya
// http://www.musion.prv.pl

tinyMCE.addToLang('',{
preview_desc : 'Podgl�d'
});